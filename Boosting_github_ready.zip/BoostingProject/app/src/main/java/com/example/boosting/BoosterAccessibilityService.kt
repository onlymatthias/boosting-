package com.example.boosting

import android.accessibilityservice.AccessibilityService
import android.app.ActivityManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import java.util.concurrent.Executors

class BoosterAccessibilityService : AccessibilityService() {
    private val executor = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        Toast.makeText(this, "Boosting service aktif", Toast.LENGTH_SHORT).show()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { }

    override fun onInterrupt() { }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        executor.execute { forceStopAll() }
        return START_NOT_STICKY
    }

    private fun forceStopAll() {
        val usage = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val list = usage.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 3600000, now)
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        var count = 0
        list?.forEach {
            val pkg = it.packageName
            if (pkg == packageName) return@forEach
            try {
                am.forceStopPackage(pkg)
                count++
            } catch (e: SecurityException) {
                Log.e("Boosting", "Failed to stop $pkg")
            }
        }
        handler.post {
            Toast.makeText(this, "Selesai. $count aplikasi dihentikan.", Toast.LENGTH_LONG).show()
        }
    }

    companion object {
        fun isServiceEnabled(ctx: Context): Boolean {
            val enabled = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            return enabled?.contains(ctx.packageName + "/" + BoosterAccessibilityService::class.java.name) ?: false
        }
    }
}
