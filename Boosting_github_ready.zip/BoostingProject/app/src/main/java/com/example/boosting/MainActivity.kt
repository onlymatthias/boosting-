package com.example.boosting

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val boostBtn: Button = findViewById(R.id.boostButton)
        boostBtn.setOnClickListener {
            if (!BoosterAccessibilityService.isServiceEnabled(this)) {
                Toast.makeText(this, "Aktifkan layanan Aksesibilitas dulu", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                return@setOnClickListener
            }
            startService(Intent(this, BoosterAccessibilityService::class.java))
        }
    }
}
